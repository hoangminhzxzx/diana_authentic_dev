<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class AccountClient extends Model
{
    //
}
