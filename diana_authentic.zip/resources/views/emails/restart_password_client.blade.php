<!DOCTYPE html>
<html>
<head>
    <title>dianaauthentic.com</title>
</head>

<body>

<a href="{{ $details['link_restore_password'] }}">Click vào đây để khôi phục lại mật khẩu </a>
</body>

</html>
