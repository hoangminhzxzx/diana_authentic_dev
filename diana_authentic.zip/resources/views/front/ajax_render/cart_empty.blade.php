<div style="text-align: center;" >
    <img src="{{ asset('/public/no-item-in-cart.png') }}" alt="">
    <p style="text-align: center;">Chưa có sản phẩm nào trong giỏ hàng</p>
    <a href="{{ route('homeFront') }}" class="btn">Tiếp tục xem hàng !!!</a>
</div>
