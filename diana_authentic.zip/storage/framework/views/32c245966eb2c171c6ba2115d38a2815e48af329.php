<div style="text-align: center;" >
    <img src="<?php echo e(asset('/public/no-item-in-cart.png')); ?>" alt="">
    <p style="text-align: center;">Chưa có sản phẩm nào trong giỏ hàng</p>
    <a href="<?php echo e(route('homeFront')); ?>" class="btn">Tiếp tục xem hàng !!!</a>
</div>
<?php /**PATH /home/wbytoxunhosting/public_html/resources/views/front/ajax_render/cart_empty.blade.php ENDPATH**/ ?>